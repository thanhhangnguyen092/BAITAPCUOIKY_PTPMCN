﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

namespace GoodBook
{
    public partial class ChiTiet : System.Web.UI.Page
    {
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string productID = Request.QueryString["Product_ID"];
                InfoDataContext db = new InfoDataContext();
                DataSet ds = new DataSet();
                dt = ds.Tables["tbl_Product"];

                DataRow dr;
                tbl_Product pro = db.tbl_Products.SingleOrDefault(t => t.ProductID.ToString() == productID.Trim());
                if (pro != null)
                {
                    hdf.Value = pro.ProductID.ToString();
                    lblImage.ImageUrl = "~/AnhSanPham/" + pro.Image;
                    lblType_Name.Text = pro.tbl_Type.TypeName;
                    lblStyle_Name.Text = pro.tbl_Style.Style_Name;
                    lblColor.Text = pro.Color;
                    txtTotal.Text = "1";
                    lblSL.Text = pro.Amount.ToString();
                    lblMaterial.Text = pro.Material;
                    lblSize.Text = pro.Size;
                    lblPrice.Text = pro.Price_Export.ToString("###,###").Replace(',', '.') + " VNĐ";
                    lblTieuDe.Text = "Chi tiết sản phẩm: " + pro.ProductName;
                }
                var tmp = (from a in db.tbl_Products
                           where a.TypeID == pro.TypeID && a.ProductID != pro.ProductID
                           select new { a.ProductID, a.ProductName, a.Image, a.Price_Export }).Take(8);
                foreach (var n in tmp)
                {
                    dr = dt.NewRow();
                    dr[0] = n.ProductID;
                    dr[1] = n.ProductName;
                    dr[2] = n.Image;
                    dr[3] = n.Price_Export.ToString("###,###").Replace(',', '.');
                    dt.Rows.Add(dr);
                }
                sanpham.DataSource = dt;
                sanpham.DataBind();
            }
        }
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {

            if (kt == true)
            {
                double total = 0;
                int soluong = 0;
                InfoDataContext db = new InfoDataContext();
                tbl_Product pro = db.tbl_Products.SingleOrDefault(t => t.ProductID.ToString() == hdf.Value.ToString());
                if (pro != null)
                {
                    Giohang gh = (Giohang)Session["giohang"];
                    soluong = int.Parse(txtTotal.Text);
                    total = Convert.ToDouble(pro.Price_Export) * Convert.ToDouble(txtTotal.Text.Trim());
                    gh.dienVaoBang(pro.ProductName, Convert.ToDouble(txtTotal.Text.Trim()), Convert.ToDouble(pro.Price_Export), pro.Size, pro.Color, pro.Material, pro.Weight.ToString(), pro.ProductID.ToString(), total);
                    Session["giohang"] = gh;
                    DataTable tb = gh.GetDataTable();
                    Response.Redirect("GioHang.aspx");

                }
            }
        }
        bool kt = true;
        protected void CtvThongBao_ServerValidate(object source, ServerValidateEventArgs args)
        {
            kt = true;
            string chuoi = args.Value.Trim();

            if (args.Value == null || args.Value.ToString() == "") kt = false;
            for (int i = 0; i < args.Value.Length; i++)
            {
                if (args.Value[i].ToString() != "1" && args.Value[i].ToString() != "2" && args.Value[i].ToString() != "3" && args.Value[i].ToString() != "4" && args.Value[i].ToString() != "5" && args.Value[i].ToString() != "6" && args.Value[i].ToString() != "7" && args.Value[i].ToString() != "8" && args.Value[i].ToString() != "0" && args.Value[i].ToString() != "9")
                {
                    kt = false;
                    break;
                }
                else
                {
                    if (int.Parse(args.Value) == 0 || int.Parse(args.Value) > int.Parse(lblSL.Text)) kt = false;
                }
            }
            if (kt == false) args.IsValid = false;
            else args.IsValid = true;
        }
    }
}
