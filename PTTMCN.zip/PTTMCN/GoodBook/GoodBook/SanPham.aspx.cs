﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace GoodBook
{
    public partial class SanPham : System.Web.UI.Page
    {
        DataTable dt;
        InfoDataContext db = new InfoDataContext();
        protected void DataList3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public void loadsanpham()
        {

            DataSet ds = new DataSet();
            dt = ds.Tables["tbl_Product"];

            DataRow dr;
            var tmp = from a in db.tbl_Products
                      from b in db.tbl_Types
                      where a.TypeID == b.TypeID && b.TypeID.ToString() == Request.QueryString["TypeID"]
                      select new { a.ProductID, a.ProductName, a.Image, a.Price_Export };
            foreach (var n in tmp)
            {
                dr = dt.NewRow();
                dr[0] = n.ProductID;
                dr[1] = n.ProductName;
                dr[2] = n.Image;
                dr[3] = n.Price_Export.ToString("###,###").Replace(',', '.');
                dt.Rows.Add(dr);
            }
            PagedDataSource pdata = new PagedDataSource();
            pdata.DataSource = ds.Tables[0].DefaultView;
            pdata.PageSize = 9;
            pdata.AllowPaging = true;
            pdata.CurrentPageIndex = CurrentP;
            sp.DataSource = pdata;
            sp.DataBind();
            LbtBack.Enabled = !pdata.IsFirstPage;
            LbtNext.Enabled = !pdata.IsLastPage;
            LblPage.Text = (CurrentP + 1) + "/" + pdata.PageCount;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string typeID = Request.QueryString["TypeID"];
                tbl_Type type = db.tbl_Types.SingleOrDefault(t => t.TypeID.ToString() == typeID.Trim());
                if (type != null)
                {
                    lblTieuDe.Text = type.TypeName;
                }
                loadsanpham();
            }
        }
        public int CurrentP
        {
            set
            {
                this.ViewState["cp"] = value;
            }
            get
            {
                if (this.ViewState["cp"] == null)
                {
                    this.ViewState["cp"] = 0;
                    return 0;
                }
                else
                {
                    return (int)this.ViewState["cp"];
                }
            }
        }

        protected void LbtBack_Click(object sender, EventArgs e)
        {
            CurrentP -= 1;
            loadsanpham();
        }

        protected void LbtNext_Click(object sender, EventArgs e)
        {
            CurrentP += 1;
            loadsanpham();
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {

        }
    }
}
