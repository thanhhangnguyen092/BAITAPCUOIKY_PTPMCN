﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace GoodBook.Admin
{
    public partial class DanhsachHD : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Username"] != null)
            {
                var a = from s in db.tbl_Accounts
                        where s.Account == Session["Username"].ToString()
                        select new { s.Power };
                foreach (var item in a)
                {
                    if (item.Power == "Nhân viên")
                    {
                        Response.Redirect("Nhaphang.aspx");
                        Response.Write("<script language='javascript'>alert('" + "Bạn không có quyền vào trang này" + "')</script>");
                    }
                }
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
            if (!IsPostBack)
                LoadHD();
        }
        InfoDataContext db = new InfoDataContext();
        public void LoadHD()
        {
            var a = from s in db.tbl_Orders
                    select new { s.OrderID, s.Date, s.Name_Deceived, s.Name_Pay, s.SumMoney, s.State };
            GridView1.DataSource = a;
            GridView1.DataBind();
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            Label lbMa = (Label)GridView1.Rows[e.RowIndex].FindControl("Label1");
            //tbl_Order o = db.tbl_Orders.SingleOrDefault(c => c.Order_ID == lbMa.Text);

            //db.SubmitChanges();
            //LoadHD();
            Response.Redirect("ThongtinHD.aspx?OrderID=" + lbMa.Text + "");
        }

        protected void LKChitiet_Click(object sender, EventArgs e)
        {
            Response.Redirect("ChitietHD.aspx?OrderID=" + Eval("OrderID"));
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
