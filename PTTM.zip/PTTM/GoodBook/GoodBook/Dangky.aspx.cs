﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

namespace GoodBook
{
    public partial class Dangky : System.Web.UI.Page
    {
        InfoDataContext db = new InfoDataContext();
        protected void Page_Load(object sender, EventArgs e)
        {
            txtTendaydu.Focus();
            Label1.Text = "";
        }

        protected void TextBox4_TextChanged(object sender, EventArgs e)
        {

        }
        private bool KiemTra()
        {
            var tmp = from a in db.tbl_Customers
                      select new { a.userID};
            foreach (var sub in tmp)
            {
                if (sub.userID == txtUser.Text)
                    return true;
            }
            return false;
        }
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (txtUser.Text == "" || txtPass.Text == "" || RePass.Text == "")
            {
                Label1.Text = "Bạn chưa nhập đầy đủ thông tin";
            }
            else
            {
                if (KiemTra())
                {
                    Label1.Text = "Tên đăng nhập đã được sử dụng";
                }
                else
                {
                    string diachi="";
                    tbl_Customer cu = new tbl_Customer();
                    cu.userID = txtUser.Text;
                    cu.Password = txtPass.Text;
                    cu.Fullname = txtTendaydu.Text;
                    if (txtDiachi.Text != "")
                    {
                        diachi = diachi + txtDiachi.Text;
                    }
                    if (txtQuanHuyen.Text != "")
                    {
                        diachi = diachi + "-"+txtQuanHuyen.Text;
                    }
                    if (txtTinhThanh.Text != "")
                    {
                        diachi = diachi + "-" + txtTinhThanh.Text;
                    }
                    if (txtQuocGia.Text != "")
                    {
                        diachi = diachi + "-" + txtQuocGia.Text;
                    }
                    cu.Address = diachi;
                    cu.Email = txtEmail.Text;
                    if (txtSDT.Text != "")
                    {
                        cu.Phone = int.Parse(txtSDT.Text);
                    }
                    db.tbl_Customers.InsertOnSubmit(cu);
                    db.SubmitChanges();
                    Response.Redirect("DangNhap.aspx");
                }
            }
        }
    }
}
