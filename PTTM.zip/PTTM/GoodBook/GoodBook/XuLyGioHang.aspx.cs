﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace GoodBook
{
    public partial class XuLyGoHang : System.Web.UI.Page
    {
        KetNoiDataBase kn = new KetNoiDataBase();
        string ThongBao = "";
        int TonTai;
        protected void Page_Load(object sender, EventArgs e)
        {
            DataTable tb = kn.getTable("SELECT * FROM tbl_Product WHERE ProductID = '" + Request.QueryString["ProductId"] + "'");
            DataTable GioHang = new DataTable();
            GioHang.Columns.Add("IdSanPham", typeof(string));
            GioHang.Columns.Add("TenSanPham", typeof(string));
            GioHang.Columns.Add("HinhAnh", typeof(string));
            GioHang.Columns.Add("SoLuong", typeof(int));
            GioHang.Columns.Add("DonGia", typeof(double));
            GioHang.Columns.Add("ThanhTien", typeof(double));
            //Kiểm tra sản phẩm có tồn tại trong giỏ hàng chưa
            if (Session["GioHang"] != null)
            {
                GioHang = (DataTable)Session["GioHang"];
                int j;
                for (j = 0; j < GioHang.Rows.Count; j++)
                {

                    if (tb.Rows[0]["ProductID"].ToString() == GioHang.Rows[j]["MaSanPham"].ToString())
                    {
                        ThongBao = "Sản phẩm này đã tồn tại trong giỏ hàng!!";
                        TonTai = 1;
                    }
                }
                //Thêm sản phẩm vào giỏ hàng
                if (TonTai == 0)
                {
                    GioHang.Rows.Add(tb.Rows[0]["ProductID"], tb.Rows[0]["ProductName"], tb.Rows[0]["Image"],
                        int.Parse(Request.QueryString["SoLuong"].ToString()), tb.Rows[0]["Price_Export"], int.Parse(tb.Rows[0]["Price_Export"].ToString()) * int.Parse(Request.QueryString["SoLuong"].ToString()));
                    ThongBao = "Thêm sản phẩm vào giỏ hàng thành công!!!";
                    Session["GioHang"] = GioHang;
                }
            }
            else
            {
                
                GioHang.Rows.Add(tb.Rows[0]["ProductID"], tb.Rows[0]["ProductName"], tb.Rows[0]["Image"],
                        int.Parse(Request.QueryString["SoLuong"].ToString()), tb.Rows[0]["Price_Export"], int.Parse(tb.Rows[0]["Price_Export"].ToString()) * int.Parse(Request.QueryString["SoLuong"].ToString()));
                ThongBao = "Thêm sản phẩm vào giỏ hàng thành công!!!";
                Session["GioHang"] = GioHang;
            }
            Session["ThongBao"] = ThongBao;
            //
            Response.Redirect("ChiTiet.aspx?ProductID=" + Request.QueryString["ProductId"] + "");

        }
    }
}