﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;

namespace GoodBook
{
    public partial class ThongTinTaiKhoan : System.Web.UI.Page
    {
        DataTable tb;
        InfoDataContext db = new InfoDataContext();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["userID"] != null)
                {
                    KetNoiDataBase kn = new KetNoiDataBase();
                    string sql = "SELECT * FROM tbl_Customer WHERE userID = '" + Request.QueryString["userID"] + "'";
                    tb = kn.getTable(sql);
                    //lbThongTin.Text = tb.Rows.Count +"";
                    if (tb.Rows.Count > 0)
                    {
                        lblTenDN.Text = tb.Rows[0]["userID"].ToString();
                        lblMatKhau.Text = "******";
                        if (tb.Rows[0]["Fullname"].ToString() != "")
                            lblTen.Text = tb.Rows[0]["Fullname"].ToString();
                        else
                            lblTen.Text = "(Chưa có thông tin)";
                        if (tb.Rows[0]["Address"].ToString() != "")
                            lblDiaChi.Text = tb.Rows[0]["Address"].ToString();
                        else
                            lblDiaChi.Text = "(Chưa có thông tin)";
                        if (tb.Rows[0]["Email"].ToString() != "")
                            lblEmail.Text = tb.Rows[0]["Email"].ToString();
                        else
                            lblEmail.Text = "(Chưa có thông tin)";
                        if (tb.Rows[0]["Phone"].ToString() != null)
                            lblSDT.Text = tb.Rows[0]["userID"].ToString();
                        else
                            lblSDT.Text = "(Chưa có thông tin)";
                        Panel2.Visible = false;
                        Panel3.Visible = false;

                    }
                    else
                    {
                        Response.Redirect("TrangChu.aspx");
                    }
                    //string user = Convert.ToString(Request.QueryString["userID"]);
                    //tbl_Customer cus = db.tbl_Customers.SingleOrDefault(t => t.userID == user);
                    //lblTenDN.Text = cus.userID.ToString();
                    //lblMatKhau.Text = "******";
                    //if (cus.Fullname != "")
                    //    lblTen.Text = cus.Fullname;
                    //else
                    //    lblTen.Text = "(Chưa có thông tin)";
                    //if (cus.Address != "")
                    //    lblDiaChi.Text = cus.Address;
                    //else
                    //    lblDiaChi.Text = "(Chưa có thông tin)";
                    //if (cus.Email != "")
                    //    lblEmail.Text = cus.Email;
                    //else
                    //    lblEmail.Text = "(Chưa có thông tin)";
                    //if (cus.Phone != null)
                    //    lblSDT.Text = cus.Phone.ToString();
                    //else
                    //    lblSDT.Text = "(Chưa có thông tin)";
                    //Panel2.Visible = false;
                    //Panel3.Visible = false;
                }
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Panel1.Visible = false;
            Panel2.Visible = false;
            Panel3.Visible = true;
            Label1.Text = "";
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            KetNoiDataBase kn3 = new KetNoiDataBase();
            string sql3 = "SELECT * FROM tbl_Customer WHERE userID = '" + Request.QueryString["userID"] + "'";
            tb = kn3.getTable(sql3);
            Panel2.Visible = true;
            Panel3.Visible = false;
            Panel1.Visible = false;
            txtTendaydu.Text = tb.Rows[0]["Fullname"].ToString();
            txtEmail.Text = tb.Rows[0]["Email"].ToString();
            txtDiachi.Text = tb.Rows[0]["Address"].ToString();
            if (tb.Rows[0]["Phone"].ToString() != null)
            {
                txtSDT.Text = tb.Rows[0]["Phone"].ToString();
            }
            string diachi = tb.Rows[0]["Address"].ToString();
            
            //string[] dc = new string[4];
            //int i = 0;
            //foreach (string con in diachi.Split('-'))
            //{
            //    dc[i] = con;
            //    i++;
            //}
            //txtDiachi.Text = dc[0];
            //txtQuanHuyen.Text = dc[1];
            //txtTinhThanh.Text = dc[2];
            //txtQuocGia.Text = dc[3];
        }

        protected void btnTiepTuc1_Click(object sender, ImageClickEventArgs e)
        {

            string user = Request.QueryString["userID"];
            KetNoiDataBase ketnoi = new KetNoiDataBase();
            string sql3 = "UPDATE tbl_Customer SET Fullname = '" +txtTendaydu.Text+ "',Email='"+txtEmail.Text+"',Address='"+txtDiachi.Text+"', Phone='"+txtSDT.Text+"'  WHERE userID = '" + Request.QueryString["userID"] + "'";
            if (ketnoi.capnhat(sql3))
            {
                Response.Write("<script language='javascript'>alert('" + "Cập nhật thành công!" + "')</script>");
            }
            //tbl_Customer cus = db.tbl_Customers.SingleOrDefault(t => t.userID == user);
            //if (cus != null)
            //{
            //    cus.Fullname = txtTendaydu.Text;
            //    cus.Address = txtDiachi.Text + "-" + txtQuanHuyen.Text + "-" + txtTinhThanh.Text + "-" + txtQuocGia.Text;
            //    cus.Email = txtEmail.Text;
            //    if (txtSDT.Text != "")
            //    {
            //        cus.Phone = Convert.ToInt32(txtSDT.Text);
            //    }
            //    db.SubmitChanges();
            //    Response.Write("<script language='javascript'>alert('" + "Cập nhật thành công!" + "')</script>");
            //}
            Panel1.Visible = true;
            Panel2.Visible = false;
            Panel3.Visible = false;
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Panel1.Visible = true;
            Panel2.Visible = false;
            Panel3.Visible = false;
        }
        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            KetNoiDataBase kn = new KetNoiDataBase();
            string sql = "SELECT * FROM tbl_Customer WHERE userID = '" + Request.QueryString["userID"] + "'";
            tb = kn.getTable(sql);
            Panel3.Visible = true;
            if (txtNewPass.Text == "" || RePass.Text == "")
            {
                Label1.Text = "Bạn chưa nhập đủ thông tin";
            }
            else
            {
                if (txtPass.Text != tb.Rows[0]["Password"].ToString())
                {
                    Label1.Text = "Mật khẩu không đúng";
                }
                else
                {
                    KetNoiDataBase ketnoi = new KetNoiDataBase();
                    string sql2 = "UPDATE tbl_Customer SET Password = '"+txtNewPass.Text+"' WHERE userID = '" + Request.QueryString["userID"] + "'";
                    if (ketnoi.capnhat(sql2))
                    {
                        //tbl_Customer cus = db.tbl_Customers.SingleOrDefault(t => t.userID == user);
                        //if (cus != null)
                        //{
                        //    cus.Password = txtNewPass.Text;
                        //    db.SubmitChanges();
                        //}
                        Response.Write("<script language='javascript'>alert('" + "Đổi mật khẩu thành công" + "')</script>");
                    }
                    Panel1.Visible = true;
                    Panel2.Visible = false;
                    Panel3.Visible = false;
                }
            }
        }
    }
}
