﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace GoodBook
{
    public partial class HangMoiVe : System.Web.UI.Page
    {
        DataTable dt;
        protected void Page_Load(object sender, EventArgs e)
        {
            phantrang();
        }
        public void phantrang()
        {
            InfoDataContext db = new InfoDataContext();
            DataSet ds = new DataSet();
            dt = ds.Tables["tbl_Product"];
            string ThongTin = "";
            DataRow dr;
            var tmp = (from a in db.tbl_Products
                       from b in db.tbl_Imports
                       from c in db.tbl_ImportDetails
                       orderby b.Date descending
                       where b.ImportID == c.ImportID && a.ProductID == c.ProductID
                       select new { a.ProductID, a.ProductName, a.Image, a.Price_Export }).Distinct().Take(15);
            foreach (var n in tmp)
            {
                ThongTin += @"<div class='khungsanpham' style ='float:left'>";
                ThongTin += @"<div class='khunganh'>";
                ThongTin += @"<img src='AnhSanPham/" + n.Image + "' alt=''/>";
                ThongTin += @"</div>";
                ThongTin += @"<div class='dong'>";
                ThongTin += "<a href ='Chitiet.aspx?ProductID=" + n.ProductID + "'>" + n.ProductName + "</a>";
                ThongTin += @"</div>";
                ThongTin += @"<div class='dong'>";
                ThongTin += @"" + n.Price_Export + " VNĐ ";
                ThongTin += @"</div>";
                ThongTin += @"</div>";
                //dr = dt.NewRow();
                //dr[0] = n.ProductID;
                //dr[1] = n.ProductName;
                //dr[2] = n.Image;
                //dr[3] = n.Price_Export.ToString("###,###").Replace(',', '.');
                //int yourPosition = 0;
                //dt.Rows.InsertAt(dr, yourPosition);
                ////dt.Rows.Add(dr);
            }
            lbThongTin.Text = ThongTin;
            //PagedDataSource pdata = new PagedDataSource();
            //pdata.DataSource = ds.Tables[0].DefaultView;
            //pdata.PageSize = 9;
            //pdata.AllowPaging = true;
            //pdata.CurrentPageIndex = CurrentP;
            //sanphammoi.DataSource = pdata;
            //sanphammoi.DataBind();
            //LbtBack.Enabled = !pdata.IsFirstPage;
            //LbtNext.Enabled = !pdata.IsLastPage;
            //LblPage.Text = (CurrentP + 1) + "/" + pdata.PageCount;
        }
        public int CurrentP
        {
            set
            {
                this.ViewState["cp"] = value;
            }
            get
            {
                if (this.ViewState["cp"] == null)
                {
                    this.ViewState["cp"] = 0;
                    return 0;
                }
                else
                {
                    return (int)this.ViewState["cp"];
                }
            }
        }

        protected void LbtBack_Click(object sender, EventArgs e)
        {
            CurrentP -= 1;
            phantrang();
        }

        protected void LbtNext_Click(object sender, EventArgs e)
        {
            CurrentP += 1;
            phantrang();
        }

    }
}
