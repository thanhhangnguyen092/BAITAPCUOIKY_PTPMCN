﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace GoodBook
{
    public class KetNoiDataBase
    {
        string connectionString = ConfigurationManager.ConnectionStrings["GoodBookDBConnectionString"].ConnectionString;
        public DataTable getTable(string query)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataTable tb = new DataTable();
            da.Fill(tb);
            return tb;
        }

        public bool capnhat(string query)
        {
            using(SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd =  new SqlCommand(query,con);
                int ketqua = cmd.ExecuteNonQuery();
                if(ketqua>0)
                {
                    return true;
                }
            }

            return false;
        }

        
        }
    }