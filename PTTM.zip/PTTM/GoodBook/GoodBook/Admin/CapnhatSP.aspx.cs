﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.IO;

namespace GoodBook.Admin
{
    public partial class CapnhatSP : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            load();
            if (Session["Username"] != null)
            {
                var a = from s in db.tbl_Accounts
                        where s.Account == Session["Username"].ToString()
                        select new { s.Power };
                foreach (var item in a)
                {
                    if (item.Power == "Nhân viên")
                    {
                        Response.Redirect("Nhaphang.aspx");
                        Response.Write("<script language='javascript'>alert('" + "Bạn không có quyền vào trang này" + "')</script>");
                    }
                }
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        InfoDataContext db = new InfoDataContext();
        private void load()
        {
            var query = from a in db.tbl_Products
                        select new { a.ProductID, a.ProductName, a.TypeID, a.StyleID, a.SupplierID, a.ProducerID, a.Image, a.Price_Import, a.Price_Export };
            GridView1.DataSource = query;
            GridView1.DataBind();
        }

        void rong()
        {
            txtMa.Text = "";
            txtTenSP.Text = "";
            txtMau.Text = "";
            txtKichthuoc.Text = "";
            txtChatlieu.Text = "";
            txtGianhap.Text = "";
            txtGiaxuat.Text = "";
            txtTrongluong.Text = "";
        }

        bool KTtontai(string ten, string loaisp, string pc, string ncc, string hsx, string mau, string kc, string cl, string gianhap, string gx, string trl)
        {
            var a = from s in db.tbl_Products
                    select new { s.ProductName, s.TypeID, s.StyleID, s.SupplierID, s.ProducerID, s.Image, s.Color, s.Material, s.Size, s.Price_Import, s.Price_Export, s.Weight };
            foreach (var item in a)
            {
                if (item.ProductName == ten && item.TypeID == int.Parse(loaisp) && item.StyleID == int.Parse(pc) && item.SupplierID == int.Parse(ncc) && item.ProducerID == int.Parse(hsx) && item.Color == mau && item.Material == cl && item.Size == kc && item.Price_Import == double.Parse(gianhap) && item.Price_Export == double.Parse(gx) && item.Weight == double.Parse(trl))
                    return false;
            }
            return true;
        }

        bool KTrong(string tensp, string gianhap, string giaxuat)
        {
            if (tensp == "" || gianhap == "" || giaxuat == "")
            {
                return false;
            }
            return true;
        }

        protected void btnNhap_Click(object sender, EventArgs e)
        {
            if (KTrong(txtTenSP.Text, txtGianhap.Text, txtGiaxuat.Text))
            {
                string anh = "";
                if (FileUpload1.HasFile)
                {
                    anh = FileUpload1.FileName.Replace(" ", "_");
                    FileUpload1.SaveAs(Server.MapPath("..//AnhSanPham") + anh);
                }
                tbl_Product p = new tbl_Product();
                p.ProductName = txtTenSP.Text;
                p.TypeID = int.Parse(drLoaiSP.SelectedValue);
                p.StyleID = int.Parse(drPhongcach.SelectedValue);
                p.SupplierID = int.Parse(drNhacungcap.SelectedValue);
                p.ProducerID = int.Parse(drNhacungcap.SelectedValue);
                p.Image = anh;
                p.Color = txtMau.Text;
                p.Material = txtChatlieu.Text;
                p.Size = txtKichthuoc.Text;
                p.Price_Import = double.Parse(txtGianhap.Text);
                p.Price_Export = int.Parse(txtGiaxuat.Text);
                p.Amount = 0;
                p.Weight = int.Parse(txtTrongluong.Text);
                db.tbl_Products.InsertOnSubmit(p);
                db.SubmitChanges();
                load();
                rong();
                Response.Write("<script language='javascript'>alert('" + "Thêm thành công." + "')</script>");
                txtTenSP.Focus();
            }
            else
            {
                Response.Write("<script language='javascript'>alert('" + "Chưa nhập đủ thông tin." + "')</script>");
                Label6.Text = "";
            }
        }

        protected void btnSua_Click(object sender, EventArgs e)
        {
            if (txtMa.Text == "")
            {
                Label6.Text = "Bạn chưa chọn sản phẩm.";
                Label2.Text = "";
            }
            else
            {
                tbl_Product p = db.tbl_Products.SingleOrDefault(c => c.ProductID == int.Parse(txtMa.Text));
                p.ProductName = txtTenSP.Text.ToString();
                p.TypeID = int.Parse(drLoaiSP.Text.ToString());
                p.StyleID = int.Parse(drPhongcach.Text.ToString());
                p.SupplierID = int.Parse(drNhacungcap.Text.ToString());
                p.ProducerID = int.Parse(drHangsanxuat.Text.ToString());
                string anh = "";
                if (FileUpload1.HasFile)
                {
                    anh = FileUpload1.FileName.Replace(" ", "_");
                    FileUpload1.SaveAs(Server.MapPath("..//AnhSanPham") + anh);
                }
                p.Image = anh;
                p.Color = txtMau.Text.ToString();
                p.Material = txtChatlieu.Text.ToString();
                p.Size = txtKichthuoc.Text.ToString();
                p.Price_Import = double.Parse(txtGianhap.Text);
                p.Price_Export = int.Parse(txtGiaxuat.Text.ToString());
                p.Weight = int.Parse(txtTrongluong.Text.ToString());
                db.SubmitChanges();
                load();
                Response.Write("<script language='javascript'>alert('" + "Sửa thành công." + "')</script>");
                Label6.Text = "";
                rong();
                txtTenSP.Focus();
                Label2.Text = "";
            }
        }

        bool KTMaSP(string ma)
        {
            var a = from s in db.tbl_ImportDetails
                    where s.ProductID == int.Parse(txtMa.Text)
                    select new { s.ProductID };
            foreach (var item in a)
            {
                if (item.ProductID == int.Parse(ma))
                    return false;
            }
            return true;
        }

        protected void btnXoa_Click(object sender, EventArgs e)
        {
            if (txtMa.Text == "")
            {
                Label6.Text = "Bạn chưa chọn sản phẩm.";
            }
            else
            {
                if (KTMaSP(txtMa.Text))
                {
                    tbl_Product p = db.tbl_Products.SingleOrDefault(c => c.ProductID == int.Parse(txtMa.Text));
                    db.tbl_Products.DeleteOnSubmit(p);
                    db.SubmitChanges();
                    load();
                    Response.Write("<script language='javascript'>alert('" + "Xoá thành công." + "')</script>");
                    rong();
                    txtTenSP.Focus();
                }
                else
                {
                    Response.Write("<script language='javascript'>alert('" + "Không thể xoá sản phẩm." + "')</script>");
                }
            }
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            load();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            Response.Redirect("CapnhatSP.aspx");
            txtTenSP.Focus();
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            Label2.Text = "Bạn chọn lại hình ảnh";
            Label lbMa = (Label)GridView1.Rows[e.NewEditIndex].FindControl("lbMa");
            tbl_Product p = db.tbl_Products.SingleOrDefault(c => c.ProductID == int.Parse(lbMa.Text));
            txtMa.Text = p.ProductID.ToString();
            txtTenSP.Text = p.ProductName.ToString();
            drLoaiSP.Text = p.TypeID.ToString();
            drPhongcach.Text = p.StyleID.ToString();
            drNhacungcap.Text = p.SupplierID.ToString();
            drHangsanxuat.Text = p.ProducerID.ToString();
            // FileUpload1.PostedFile = p.Image.ToString();
            txtMau.Text = p.Color.ToString();
            txtChatlieu.Text = p.Material.ToString();
            txtKichthuoc.Text = p.Size.ToString();
            txtGianhap.Text = p.Price_Import.ToString();
            txtGiaxuat.Text = p.Price_Export.ToString();
            txtTrongluong.Text = p.Weight.ToString();
            GridView1.EditIndex = e.NewEditIndex;
            load();
            Label6.Text = "";
        }
    }
}
