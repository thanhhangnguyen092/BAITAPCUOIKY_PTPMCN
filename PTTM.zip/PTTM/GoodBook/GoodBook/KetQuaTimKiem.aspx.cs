﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace GoodBook
{
    public partial class KetQuaTimKiem : System.Web.UI.Page
    {
        //Data a = new Data(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        //DataSet ds = new DataSet();
        DataTable dt;

        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                phantrang();
            }
        }
        public void phantrang()
        {
            String ThongTin = "";
            InfoDataContext db = new InfoDataContext();
            DataSet ds = new DataSet();
            dt = ds.Tables["tbl_Product"];
            string dieukien = Convert.ToString(Request.QueryString["DieuKien"]);
            IEnumerable<tbl_Product> tmp = db.ExecuteQuery<tbl_Product>(@"SELECT tbl_Type.*,tbl_Product.*,tbl_Producer.* FROM tbl_Type,tbl_Product,tbl_Producer where tbl_Type.TypeID=tbl_Product.TypeID and tbl_Product.ProducerID=tbl_Producer.ProducerID and" + Convert.ToString(Request.QueryString["DieuKien"]));
            foreach (var n in tmp)
            {
                ThongTin += @"<div class='khungsanpham' style ='float:left'>";
                ThongTin += @"<div class='khunganh'>";
                ThongTin += @"<img src='AnhSanPham/" + n.Image + "' alt=''/>";
                ThongTin += @"</div>";
                ThongTin += @"<div class='dong'>";
                ThongTin += "<a href ='Chitiet.aspx?ProductID=" + n.ProductID + "'>" + n.ProductName + "</a>";
                ThongTin += @"</div>";
                ThongTin += @"<div class='dong'>";
                ThongTin += @"" + n.Price_Export + " VNĐ ";
                ThongTin += @"</div>";
                ThongTin += @"</div>";
            }

            lbThongTin.Text = ThongTin;
            //PagedDataSource pdata = new PagedDataSource();
            //if (ds.Tables.Count == 0)
            //{
            //    lblTieuDe.Text = "Có 0 kết quả được tìm thấy";
            //}
            //else
            //{
            //    pdata.DataSource = ds.Tables["tbl_Product"].DefaultView;
            //    pdata.PageSize = 9;
            //    pdata.AllowPaging = true;
            //    pdata.CurrentPageIndex = CurrentP;
            //    TimKiem.DataSource = pdata;
            //    TimKiem.DataBind();
            //    int sobanghi = ds.Tables[0].Rows.Count;
            //    lblTieuDe.Text = "Có " + sobanghi + " kết quả được tìm thấy";
            //    LbtBack.Enabled = !pdata.IsFirstPage;
            //    LbtNext.Enabled = !pdata.IsLastPage;
            //    LblPage.Text = (CurrentP + 1) + "/" + pdata.PageCount;
            //}
        }
        public int CurrentP
        {
            set
            {
                this.ViewState["cp"] = value;
            }
            get
            {
                if (this.ViewState["cp"] == null)
                {
                    this.ViewState["cp"] = 0;
                    return 0;
                }
                else
                {
                    return (int)this.ViewState["cp"];
                }
            }
        }

        protected void LbtBack_Click(object sender, EventArgs e)
        {
            CurrentP -= 1;
            phantrang();
        }

        protected void LbtNext_Click(object sender, EventArgs e)
        {
            CurrentP += 1;
            phantrang();
        }
    }
}
